// Ponto de entrada: conecta no banco, cria as tabelas (se faltarem) e liga o servidor.
require('dotenv').config();
const app = require('./codigo-fonte/aplicacao');
const { sequelize } = require('./codigo-fonte/modelos');

const PORT = process.env.PORT || 3000;

async function iniciar() {
  try {
    if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET não definido no ambiente');
    await sequelize.authenticate();
    await sequelize.sync(); // cria as tabelas se ainda não existirem (não apaga dados)
    app.listen(PORT, () => console.log(`API rodando na porta ${PORT}`));
  } catch (erro) {
    console.error('Falha ao iniciar a API:', erro.message);
    process.exit(1);
  }
}

iniciar();
