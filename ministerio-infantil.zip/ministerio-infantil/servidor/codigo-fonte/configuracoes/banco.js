// Configuração da conexão com o banco relacional (MySQL) via Sequelize.
require('dotenv').config();
const { Sequelize } = require('sequelize');

const opcoes = {
  dialect: 'mysql',
  logging: false,
  dialectOptions: process.env.DB_SSL === 'true' ? { ssl: { rejectUnauthorized: false } } : {},
};

// Aceita uma URL única (mysql://usuario:senha@host:3306/banco) ou variáveis separadas
const sequelize = process.env.DATABASE_URL
  ? new Sequelize(process.env.DATABASE_URL, opcoes)
  : new Sequelize(
      process.env.DB_NAME || 'ministerio_infantil',
      process.env.DB_USER || 'root',
      process.env.DB_PASSWORD || '',
      { ...opcoes, host: process.env.DB_HOST || 'localhost', port: Number(process.env.DB_PORT) || 3306 }
    );

module.exports = sequelize;
