// Configuração do Express: CORS, JSON, rotas e tratamento de erros.
const express = require('express');
const cors = require('cors');

const app = express();

const origens = (process.env.FRONTEND_URL || '')
  .split(',')
  .map((o) => o.trim().replace(/\/$/, ''))
  .filter(Boolean);

app.use(
  cors({
    origin(origin, callback) {
      // Sem origin = ferramentas como Insomnia/Postman; com origin = só o front liberado
      if (!origin || origens.includes(origin)) return callback(null, true);
      return callback(new Error('Origem não permitida pelo CORS'));
    },
  })
);
app.use(express.json());

app.get('/', (req, res) => res.json({ status: 'ok', api: 'Check-in Ministério Infantil' }));
app.use('/auth', require('./rotas/rotasAutenticacao'));
app.use('/criancas', require('./rotas/rotasCrianca'));

// Rota inexistente
app.use((req, res) => res.status(404).json({ erro: 'Rota não encontrada' })); //mostra que tentou usar uma rota não existente

// Erros gerais: nunca expõe detalhes internos ou segredos
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ erro: 'JSON inválido' });
  if (err.message === 'Origem não permitida pelo CORS') return res.status(403).json({ erro: err.message });
  console.error(err);
  res.status(500).json({ erro: 'Erro interno do servidor' });
});

module.exports = app;
