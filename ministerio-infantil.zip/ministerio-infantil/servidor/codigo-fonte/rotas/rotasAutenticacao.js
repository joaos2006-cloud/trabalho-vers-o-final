const router = require('express').Router();
const auth = require('../intermediarios/autenticacao');
const controller = require('../controladores/controladorAutenticacao');

router.post('/register', controller.register); // pública
router.post('/login', controller.login); // pública
router.get('/me', auth, controller.me); // protegida

module.exports = router;
