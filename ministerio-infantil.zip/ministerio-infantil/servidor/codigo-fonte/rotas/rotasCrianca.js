const router = require('express').Router();
const auth = require('../intermediarios/autenticacao');
const controller = require('../controladores/controladorCrianca');

router.use(auth); // todas as rotas abaixo exigem estar logado

router.get('/', controller.listar);
router.get('/:id', controller.detalhar);
router.post('/', controller.criar);
router.put('/:id', controller.atualizar);
router.delete('/:id', controller.excluir);
router.post('/:id/checkin', controller.checkin);
router.post('/:id/checkout', controller.checkout);

module.exports = router;
