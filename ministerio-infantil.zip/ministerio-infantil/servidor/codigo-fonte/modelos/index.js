// Reúne os modelos e define o relacionamento 1 usuário : N crianças.
const sequelize = require('../configuracoes/banco');
const Usuario = require('./Usuario');
const Crianca = require('./Crianca');

Usuario.hasMany(Crianca, { foreignKey: 'usuario_id', as: 'criancas' });
Crianca.belongsTo(Usuario, { foreignKey: 'usuario_id' });

module.exports = { sequelize, Usuario, Crianca };
