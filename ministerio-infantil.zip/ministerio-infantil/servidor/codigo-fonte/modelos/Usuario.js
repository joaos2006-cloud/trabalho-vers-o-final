const { DataTypes } = require('sequelize');
const sequelize = require('../configuracoes/banco');

const Usuario = sequelize.define(
  'Usuario',
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    nome: { type: DataTypes.STRING(100), allowNull: false },
    email: { type: DataTypes.STRING(150), allowNull: false, unique: true },
    senha_hash: { type: DataTypes.STRING(100), allowNull: false },
  },
  { tableName: 'usuarios', createdAt: 'created_at', updatedAt: false }
);

module.exports = Usuario;
