const { DataTypes } = require('sequelize');
const sequelize = require('../configuracoes/banco');

const TURMAS = ['Berçário', 'Maternal', 'Jardim', 'Juniores', 'Pré-adolescentes'];
const STATUS = ['ausente', 'presente'];

const Crianca = sequelize.define(
  'Crianca',
  {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    usuario_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: 'usuarios', key: 'id' },
      onDelete: 'CASCADE',
    },
    nome: { type: DataTypes.STRING(100), allowNull: false },
    data_nascimento: { type: DataTypes.DATEONLY, allowNull: false },
    turma: { type: DataTypes.STRING(30), allowNull: false },
    responsavel: { type: DataTypes.STRING(100), allowNull: false },
    telefone_responsavel: { type: DataTypes.STRING(20) },
    observacoes: { type: DataTypes.TEXT },
    status: { type: DataTypes.STRING(10), allowNull: false, defaultValue: 'ausente' },
    ultimo_checkin: { type: DataTypes.DATE },
  },
  { tableName: 'criancas', createdAt: 'created_at', updatedAt: false }
);

Crianca.TURMAS = TURMAS;
Crianca.STATUS = STATUS;

module.exports = Crianca;
