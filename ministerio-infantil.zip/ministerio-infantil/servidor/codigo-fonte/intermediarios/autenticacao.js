// Middleware de autenticação: exige "Authorization: Bearer <token>" válido.
const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ erro: 'Token ausente' });
  }

  try {
    const payload = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);
    req.usuarioId = payload.id; // as rotas usam este id para filtrar os dados
    next();
  } catch {
    return res.status(401).json({ erro: 'Token inválido ou expirado' });
  }
};
