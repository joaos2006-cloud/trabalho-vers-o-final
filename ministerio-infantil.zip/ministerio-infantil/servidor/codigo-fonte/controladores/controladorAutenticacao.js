const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Usuario } = require('../modelos');

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function dadosPublicos(u) {
  return { id: u.id, nome: u.nome, email: u.email }; // nunca devolve a senha/hash
}

exports.register = async (req, res, next) => {
  try {
    const nome = String(req.body.nome || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    if (nome.length < 2) return res.status(400).json({ erro: 'Informe o nome (mínimo 2 caracteres)' });
    if (!EMAIL_REGEX.test(email)) return res.status(400).json({ erro: 'E-mail inválido' });
    if (senha.length < 6) return res.status(400).json({ erro: 'A senha deve ter no mínimo 6 caracteres' });

    if (await Usuario.findOne({ where: { email } })) {
      return res.status(409).json({ erro: 'E-mail já cadastrado' });
    }

    const senha_hash = await bcrypt.hash(senha, 10);
    const usuario = await Usuario.create({ nome, email, senha_hash });
    res.status(201).json(dadosPublicos(usuario));
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ erro: 'E-mail já cadastrado' });
    }
    next(err);
  }
};

exports.login = async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    if (!email || !senha) return res.status(400).json({ erro: 'Informe e-mail e senha' });

    const usuario = await Usuario.findOne({ where: { email } });
    const ok = usuario && (await bcrypt.compare(senha, usuario.senha_hash));
    if (!ok) return res.status(401).json({ erro: 'E-mail ou senha incorretos' });

    const token = jwt.sign({ id: usuario.id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '2h',
    });
    res.json({ token, usuario: dadosPublicos(usuario) });
  } catch (err) {
    next(err);
  }
};

exports.me = async (req, res, next) => {
  try {
    const usuario = await Usuario.findByPk(req.usuarioId);
    if (!usuario) return res.status(401).json({ erro: 'Usuário não encontrado' });
    res.json(dadosPublicos(usuario));
  } catch (err) {
    next(err);
  }
};
