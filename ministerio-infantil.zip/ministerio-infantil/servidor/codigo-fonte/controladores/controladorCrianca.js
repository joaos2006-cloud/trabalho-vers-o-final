const { Crianca } = require('../modelos');

// Valida os campos do corpo; retorna { erro } ou { dados }
function validar(body) {
  const nome = String(body.nome || '').trim();
  const responsavel = String(body.responsavel || '').trim();
  const turma = String(body.turma || '');
  const nascimento = String(body.data_nascimento || '');
  const telefone = String(body.telefone_responsavel || '').trim();
  const observacoes = String(body.observacoes || '').trim();

  if (nome.length < 2) return { erro: 'Informe o nome da criança' };
  if (responsavel.length < 2) return { erro: 'Informe o nome do responsável' };
  if (!Crianca.TURMAS.includes(turma)) {
    return { erro: `Turma inválida. Use: ${Crianca.TURMAS.join(', ')}` };
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(nascimento) || isNaN(Date.parse(nascimento))) {
    return { erro: 'Data de nascimento inválida (use AAAA-MM-DD)' };
  }
  if (new Date(nascimento) > new Date()) return { erro: 'A data de nascimento não pode ser futura' };
  if (telefone && !/^[\d\s()+-]{8,20}$/.test(telefone)) return { erro: 'Telefone inválido' };

  return {
    dados: {
      nome,
      responsavel,
      turma,
      data_nascimento: nascimento,
      telefone_responsavel: telefone || null,
      observacoes: observacoes || null,
    },
  };
}

// Valida o :id e busca a criança SOMENTE se pertencer ao usuário do token
async function buscarPropria(req, res) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    res.status(400).json({ erro: 'Identificador inválido' });
    return null;
  }
  const crianca = await Crianca.findOne({ where: { id, usuario_id: req.usuarioId } });
  if (!crianca) {
    res.status(404).json({ erro: 'Criança não encontrada' });
    return null;
  }
  return crianca;
}

exports.listar = async (req, res, next) => {
  try {
    const criancas = await Crianca.findAll({
      where: { usuario_id: req.usuarioId },
      order: [['nome', 'ASC']],
    });
    res.json(criancas);
  } catch (err) {
    next(err);
  }
};

exports.detalhar = async (req, res, next) => {
  try {
    const crianca = await buscarPropria(req, res);
    if (crianca) res.json(crianca);
  } catch (err) {
    next(err);
  }
};

exports.criar = async (req, res, next) => {
  try {
    const { erro, dados } = validar(req.body);
    if (erro) return res.status(400).json({ erro });

    // usuario_id vem do token, nunca do corpo da requisição
    const crianca = await Crianca.create({ ...dados, usuario_id: req.usuarioId });
    res.status(201).json(crianca);
  } catch (err) {
    next(err);
  }
};

exports.atualizar = async (req, res, next) => {
  try {
    const crianca = await buscarPropria(req, res);
    if (!crianca) return;

    const { erro, dados } = validar(req.body);
    if (erro) return res.status(400).json({ erro });

    await crianca.update(dados);
    res.json(crianca);
  } catch (err) {
    next(err);
  }
};

exports.excluir = async (req, res, next) => {
  try {
    const crianca = await buscarPropria(req, res);
    if (!crianca) return;
    await crianca.destroy();
    res.json({ mensagem: 'Criança excluída' });
  } catch (err) {
    next(err);
  }
};

exports.checkin = async (req, res, next) => {
  try {
    const crianca = await buscarPropria(req, res);
    if (!crianca) return;
    if (crianca.status === 'presente') {
      return res.status(409).json({ erro: 'A criança já está com check-in feito' });
    }
    await crianca.update({ status: 'presente', ultimo_checkin: new Date() });
    res.json(crianca);
  } catch (err) {
    next(err);
  }
};

exports.checkout = async (req, res, next) => {
  try {
    const crianca = await buscarPropria(req, res);
    if (!crianca) return;
    if (crianca.status === 'ausente') {
      return res.status(409).json({ erro: 'A criança não está com check-in ativo' });
    }
    await crianca.update({ status: 'ausente' });
    res.json(crianca);
  } catch (err) {
    next(err);
  }
};
