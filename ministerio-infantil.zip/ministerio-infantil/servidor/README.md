# Back-end: API do Check-in Kids
Veja o README principal (na raiz do projeto) para o tema, o diagrama, a tabela de rotas e o deploy.

```bash
npm install
# antes: execute database/esquema.sql no MySQL
cp .env.example .env   # configure DB_USER, DB_PASSWORD e JWT_SECRET
npm run seed           # opcional: dados fictícios de exemplo
npm run dev
```
Estrutura: `servidor.js` (liga o servidor) · `codigo-fonte/aplicacao.js` (Express, CORS, rotas) · `codigo-fonte/config` (banco) ·
`codigo-fonte/models` · `codigo-fonte/controllers` · `codigo-fonte/routes` · `codigo-fonte/intermediarios/autenticacao.js` (JWT) · `banco-de-dados/esquema.sql`.
