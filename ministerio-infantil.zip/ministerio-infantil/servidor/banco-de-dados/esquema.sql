-- Script de criação do banco e das tabelas (MySQL 5.7+ / 8 / MariaDB).
-- Equivalente ao que o Sequelize cria ao iniciar a API (sequelize.sync()).
-- Em bancos em nuvem que já fornecem o banco pronto, pule as 2 primeiras linhas.
CREATE DATABASE IF NOT EXISTS ministerio_infantil CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ministerio_infantil;

CREATE TABLE IF NOT EXISTS usuarios (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  senha_hash  VARCHAR(100) NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS criancas (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id            INT NOT NULL,
  nome                  VARCHAR(100) NOT NULL,
  data_nascimento       DATE NOT NULL,
  turma                 VARCHAR(30) NOT NULL,
  responsavel           VARCHAR(100) NOT NULL,
  telefone_responsavel  VARCHAR(20),
  observacoes           TEXT,
  status                VARCHAR(10) NOT NULL DEFAULT 'ausente',
  ultimo_checkin        DATETIME,
  created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_criancas_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE,
  INDEX idx_criancas_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dois registros de exemplo (fictícios) para o usuário de id 1, depois de criá-lo pelo sistema:
-- INSERT INTO criancas (usuario_id, nome, data_nascimento, turma, responsavel, telefone_responsavel)
-- VALUES (1, 'Ana Souza (exemplo)', '2021-03-14', 'Maternal', 'Carla Souza', '(49) 99999-0001'),
--        (1, 'Pedro Lima (exemplo)', '2016-08-02', 'Juniores', 'Marcos Lima', '(49) 99999-0002');
