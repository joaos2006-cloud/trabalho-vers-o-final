# Check-in Kids: sistema de check-in do ministério infantil

## Tema e problema que resolve
Em muitas igrejas, a entrada e a saída das crianças no ministério infantil são controladas em papel.
O **Check-in Kids** permite que cada professor/voluntário cadastre as crianças da própria turma,
registre o **check-in** (entrada) e o **check-out** (saída) a cada culto e consulte rapidamente o contato do
responsável e observações importantes (como alergias).

**Público usuário:** professores e voluntários do ministério infantil.
**Informação gerenciada:** crianças (nome, nascimento, turma, responsável, telefone, observações, presença).

## Decisões de modelagem
- **Duas tabelas** (`usuarios` e `criancas`), relação **1 usuário : N crianças** por chave estrangeira.
- Cada voluntário vê **apenas as crianças que cadastrou**: toda consulta filtra por `usuario_id` (vindo do token JWT, nunca do corpo da requisição).
- O check-in é um **estado** da criança (`status` = `ausente`/`presente`) com a data/hora em `ultimo_checkin`.
- Senhas guardadas apenas como **hash bcrypt**.


## Diagrama das tabelas
```
┌────────────────────┐          ┌─────────────────────────────┐
│ usuarios           │          │ criancas                    │
├────────────────────┤          ├─────────────────────────────┤
│ id (PK)            │◄──┐      │ id (PK)                     │
│ nome               │   │ 1:N  │ usuario_id (FK → usuarios)  │
│ email (UNIQUE)     │   └──────│ nome                        │
│ senha_hash         │          │ data_nascimento (DATE)      │
│ created_at         │          │ turma (categoria)           │
└────────────────────┘          │ responsavel                 │
                                │ telefone_responsavel        │
                                │ observacoes (TEXT)          │
                                │ status (ausente/presente)   │
                                │ ultimo_checkin (TIMESTAMP)  │
                                │ created_at                  │
                                └─────────────────────────────┘
```
Script SQL de criação: `servidor/banco-de-dados/esquema.sql` (o Sequelize também cria as tabelas ao iniciar).

## Tecnologias
- **Front-end:** React 18, Vite, React Router, Axios
- **Back-end:** Node.js, Express, Sequelize (ORM), MySQL, JWT, bcryptjs, CORS
- **Deploy sugerido:** Vercel (front), Render (API) e um MySQL em nuvem (veja a seção Publicação)

## Requisitos
Node.js 18+ e um banco MySQL (local, como XAMPP/MySQL Workbench, ou em nuvem).

## Como executar localmente

### 1. Back-end
```bash
# 1) Crie o banco: execute servidor/banco-de-dados/esquema.sql no MySQL (Workbench, phpMyAdmin ou terminal)
#    Terminal: mysql -u root -p < database/esquema.sql
cd servidor
npm install
cp .env.example .env      # edite DB_USER, DB_PASSWORD e JWT_SECRET
npm run seed              # opcional: cria demo@igreja.com / 123456 com 2 crianças fictícias
npm run dev               # http://localhost:3000
```

### 2. Front-end
```bash
cd interface
npm install
cp .env.example .env      # VITE_API_URL=http://localhost:3000
npm run dev               # http://localhost:5173
```

## Variáveis de ambiente

| Projeto | Variável | Descrição |
|---|---|---|
| servidor | `PORT` | Porta (o Render define sozinho) |
| servidor | `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` | Conexão com o MySQL |
| servidor | `DATABASE_URL` | Opcional: URL única `mysql://usuario:senha@host:3306/banco` (substitui as `DB_*`) |
| servidor | `DB_SSL` | `true` se o banco em nuvem exigir SSL |
| servidor | `JWT_SECRET` | Segredo para assinar o JWT |
| servidor | `JWT_EXPIRES_IN` | Validade do token (ex.: `2h`) |
| servidor | `FRONTEND_URL` | URL(s) do front liberadas no CORS |
| interface | `VITE_API_URL` | URL pública da API |

## Rotas da API
Todas retornam JSON. As marcadas como **protegidas** exigem `Authorization: Bearer <token>`.

| Método | Rota | Acesso | Descrição | Sucesso |
|---|---|---|---|---|
| POST | `/auth/registrar` | pública | Cria usuário (guarda só o hash) | 201 |
| POST | `/auth/login` | pública | Valida credenciais e retorna JWT | 200 |
| GET | `/auth/me` | protegida | Dados do usuário logado | 200 |
| GET | `/criancas` | protegida | Lista as crianças do usuário | 200 |
| GET | `/criancas/:id` | protegida | Detalhe de uma criança própria | 200 |
| POST | `/criancas` | protegida | Cadastra criança | 201 |
| PUT | `/criancas/:id` | protegida | Atualiza criança própria | 200 |
| DELETE | `/criancas/:id` | protegida | Exclui criança própria | 200 |
| POST | `/criancas/:id/checkin` | protegida | Marca presença | 200 |
| POST | `/criancas/:id/checkout` | protegida | Marca saída | 200 |

**Códigos de erro:** 400 entrada inválida · 401 token ausente/inválido/expirado ou login incorreto ·
404 criança inexistente ou de outro usuário · 409 e-mail duplicado (ou check-in/saída repetidos) · 500 erro interno.

**Exemplo de corpo para `POST /criancas`:**
```json
{
  "nome": "Ana Souza (exemplo)",
  "data_nascimento": "2021-03-14",
  "turma": "Maternal",
  "responsavel": "Carla Souza",
  "telefone_responsavel": "(49) 99999-0001",
  "observacoes": "Alergia a amendoim"
}
```
Turmas aceitas: Berçário, Maternal, Jardim, Juniores, Pré-adolescentes.

## Publicação (deploy)

1. **Banco (MySQL em nuvem):** o Render não oferece MySQL, então use um serviço externo (por exemplo Railway, Aiven ou TiDB Cloud; confira as condições do plano gratuito na hora, pois mudam). Crie o banco, copie host, porta, usuário, senha e nome (ou a URL) e execute `servidor/banco-de-dados/esquema.sql` (sem as 2 primeiras linhas se o serviço já entrega o banco criado).
2. **API (Render):** Web Service apontando para o repositório do `servidor`.
   Build: `npm install` · Start: `node servidor.js`.
   Variáveis: `DB_*` (ou `DATABASE_URL`), `DB_SSL` se exigido, `JWT_SECRET`, `JWT_EXPIRES_IN`, `FRONTEND_URL` (URL da Vercel, sem barra no final).
3. **Front (Vercel):** importe o repositório do `interface`. Variável: `VITE_API_URL` = URL do Render.
   O arquivo `vercel.json` já cuida do recarregamento (F5) das páginas privadas.
4. Teste o fluxo completo usando apenas as URLs de produção.

**URLs públicas (preencher após o deploy):**
- Front-end: `https://___________.vercel.app`
- API: `https://___________.onrender.com`

## Testes realizados (checklist)
- [ ] Registro, e-mail duplicado (409), dados inválidos (400)
- [ ] Login, `/auth/me`, token ausente/expirado (401)
- [ ] CRUD completo das crianças
- [ ] Dois usuários: os registros de um não aparecem para o outro (404 ao tentar o id do outro)
- [ ] Persistência após reiniciar o servidor e após recarregar a página
- [ ] Fluxo completo em produção
