# Front-end: Check-in Kids
Veja o README principal (na raiz do projeto) para o tema, rotas da API e deploy.

```bash
npm install
cp .env.example .env   # VITE_API_URL com a URL da API
npm run dev
```
Estrutura: `codigo-fonte/servicos/api.js` (axios + Bearer + tratamento de 401) · `codigo-fonte/contexto/ContextoAutenticacao.jsx` (sessão) ·
`codigo-fonte/componentes/RotaPrivada.jsx` · `codigo-fonte/paginas/*` (telas) · `vercel.json` (rewrite para recarregar páginas privadas).
