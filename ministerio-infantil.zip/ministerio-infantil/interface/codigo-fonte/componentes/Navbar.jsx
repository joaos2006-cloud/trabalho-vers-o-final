import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexto/ContextoAutenticacao.jsx';

export default function Navbar() {
  const { usuario, logout } = useAuth();
  const navigate = useNavigate();

  function sair() {
    logout();
    navigate('/');
  }

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="marca">Check-in Kids</Link>
        <nav>
          {usuario ? (
            <>
              <NavLink to="/criancas">Crianças</NavLink>
              <span className="saudacao">Olá, {usuario.nome.split(' ')[0]}</span>
              <button className="btn btn-link" onClick={sair}>Sair</button>
            </>
          ) : (
            <>
              <NavLink to="/login">Entrar</NavLink>
              <NavLink to="/registro" className="btn btn-sol">Criar conta</NavLink>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
