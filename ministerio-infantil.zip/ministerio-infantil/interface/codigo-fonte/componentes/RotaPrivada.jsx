// Protege as rotas: sem login, redireciona para /login.
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexto/ContextoAutenticacao.jsx';

export default function RotaPrivada() {
  const { usuario, carregando } = useAuth();
  const local = useLocation();

  if (carregando) return <p className="estado">Verificando sessão…</p>;
  if (!usuario) {
    return <Navigate to="/login" replace state={{ aviso: 'Entre para acessar essa área.', de: local.pathname }} />;
  }
  return <Outlet />;
}
