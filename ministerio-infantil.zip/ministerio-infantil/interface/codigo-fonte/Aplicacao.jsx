// Define as rotas do interface. As privadas ficam dentro de <RotaPrivada>.
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './componentes/Navbar.jsx';
import RotaPrivada from './componentes/RotaPrivada.jsx';
import Home from './paginas/Inicio.jsx';
import Login from './paginas/Entrar.jsx';
import Register from './paginas/Cadastro.jsx';
import Criancas from './paginas/Criancas.jsx';
import CriancaForm from './paginas/CriancaForm.jsx';
import CriancaDetalhe from './paginas/CriancaDetalhe.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/registro" element={<Register />} />
          <Route element={<RotaPrivada />}>
            <Route path="/criancas" element={<Criancas />} />
            <Route path="/criancas/nova" element={<CriancaForm />} />
            <Route path="/criancas/:id" element={<CriancaDetalhe />} />
            <Route path="/criancas/:id/editar" element={<CriancaForm />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
