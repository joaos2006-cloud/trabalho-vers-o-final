// Deve ser igual à lista de turmas validada no servidor.
export const TURMAS = ['Berçário', 'Maternal', 'Jardim', 'Juniores', 'Pré-adolescentes'];

export function formatarData(iso) {
  if (!iso) return '—';
  const [a, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${a}`;
}

export function formatarDataHora(iso) {
  return iso ? new Date(iso).toLocaleString('pt-BR') : 'Nunca';
}

// Extrai a mensagem de erro retornada pela API (ou explica falha de rede)
export function mensagemDeErro(err) {
  if (!err.response) return 'Não foi possível conectar à API. Verifique sua internet e tente de novo.';
  return err.response.data?.erro || 'Ocorreu um erro inesperado.';
}
