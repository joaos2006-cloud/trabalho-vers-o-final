// Cliente HTTP único. A URL da API vem da variável de ambiente VITE_API_URL.
import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL });

let aoExpirarSessao = () => {};
export function definirAoExpirarSessao(fn) {
  aoExpirarSessao = fn;
}

// Envia o token JWT como Bearer em toda chamada
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// 401 em rota protegida = token expirado/inválido: encerra a sessão
api.interceptors.response.use(
  (resposta) => resposta,
  (erro) => {
    const ehLogin = erro.config?.url?.startsWith('/auth/login');
    if (erro.response?.status === 401 && !ehLogin && localStorage.getItem('token')) {
      aoExpirarSessao();
    }
    return Promise.reject(erro);
  }
);

export default api;
