// Guarda o usuário logado e o token; recupera a sessão ao recarregar a página.
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { definirAoExpirarSessao } from '../servicos/api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [carregando, setCarregando] = useState(true); // verificando token salvo
  const navigate = useNavigate();

  const logout = useCallback(() => {
    localStorage.removeItem('token');
    setUsuario(null);
  }, []);

  // Sessão expirada: limpa e manda para o login com aviso
  useEffect(() => {
    definirAoExpirarSessao(() => {
      logout();
      navigate('/login', { state: { aviso: 'Sua sessão expirou. Entre novamente.' } });
    });
  }, [logout, navigate]);

  // Ao abrir/recarregar: se há token, confirma na API quem é o usuário
  useEffect(() => {
    if (!localStorage.getItem('token')) {
      setCarregando(false);
      return;
    }
    api
      .get('/auth/me')
      .then((r) => setUsuario(r.data))
      .catch(() => {}) // 401 já é tratado pelo interceptor; falha de rede mantém o token
      .finally(() => setCarregando(false));
  }, []);

  async function login(email, senha) {
    const r = await api.post('/auth/login', { email, senha });
    localStorage.setItem('token', r.data.token);
    setUsuario(r.data.usuario);
  }

  return (
    <AuthContext.Provider value={{ usuario, carregando, login, logout }}>{children}</AuthContext.Provider>
  );
}
