// Formulário usado para cadastrar (/criancas/nova) e editar (/criancas/:id/editar).
import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api from '../servicos/api.js';
import Mensagem from '../componentes/Mensagem.jsx';
import { TURMAS, mensagemDeErro } from '../constantes.js';

const VAZIO = {
  nome: '',
  data_nascimento: '',
  turma: '',
  responsavel: '',
  telefone_responsavel: '',
  observacoes: '',
};

export default function CriancaForm() {
  const { id } = useParams();
  const editando = Boolean(id);
  const navigate = useNavigate();
  const [form, setForm] = useState(VAZIO);
  const [carregando, setCarregando] = useState(editando);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState('');

  // Na edição, busca o registro e preenche os campos
  useEffect(() => {
    if (!editando) return;
    api
      .get(`/criancas/${id}`)
      .then((r) => {
        const c = r.data;
        setForm({
          nome: c.nome,
          data_nascimento: c.data_nascimento,
          turma: c.turma,
          responsavel: c.responsavel,
          telefone_responsavel: c.telefone_responsavel || '',
          observacoes: c.observacoes || '',
        });
      })
      .catch((err) => setErro(mensagemDeErro(err)))
      .finally(() => setCarregando(false));
  }, [id, editando]);

  const alterar = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  function validar() {
    if (form.nome.trim().length < 2) return 'Informe o nome da criança.';
    if (!form.data_nascimento) return 'Informe a data de nascimento.';
    if (new Date(form.data_nascimento) > new Date()) return 'A data de nascimento não pode ser futura.';
    if (!form.turma) return 'Escolha a turma.';
    if (form.responsavel.trim().length < 2) return 'Informe o nome do responsável.';
    return '';
  }

  async function enviar(e) {
    e.preventDefault();
    const problema = validar();
    if (problema) return setErro(problema);

    setErro('');
    setEnviando(true);
    try {
      if (editando) await api.put(`/criancas/${id}`, form);
      else await api.post('/criancas', form);
      navigate('/criancas', {
        state: { sucesso: editando ? 'Cadastro atualizado.' : 'Criança cadastrada com sucesso.' },
      });
    } catch (err) {
      setErro(mensagemDeErro(err)); // o que foi digitado permanece no formulário
    } finally {
      setEnviando(false);
    }
  }

  if (carregando) return <p className="estado">Carregando cadastro…</p>;

  return (
    <form className="cartao form-largo" onSubmit={enviar} noValidate>
      <h1>{editando ? 'Editar criança' : 'Cadastrar criança'}</h1>
      <Mensagem>{erro}</Mensagem>

      <label>Nome da criança
        <input name="nome" value={form.nome} onChange={alterar} />
      </label>

      <div className="linha">
        <label>Data de nascimento
          <input type="date" name="data_nascimento" value={form.data_nascimento} onChange={alterar} />
        </label>
        <label>Turma
          <select name="turma" value={form.turma} onChange={alterar}>
            <option value="">Escolha…</option>
            {TURMAS.map((t) => <option key={t}>{t}</option>)}
          </select>
        </label>
      </div>

      <div className="linha">
        <label>Responsável
          <input name="responsavel" value={form.responsavel} onChange={alterar} />
        </label>
        <label>Telefone do responsável
          <input type="tel" name="telefone_responsavel" value={form.telefone_responsavel} onChange={alterar} placeholder="(49) 99999-9999" />
        </label>
      </div>

      <label>Observações (alergias, cuidados)
        <textarea name="observacoes" rows="3" value={form.observacoes} onChange={alterar} />
      </label>

      <div className="acoes">
        <button className="btn btn-sol" disabled={enviando}>{enviando ? 'Salvando…' : 'Salvar'}</button>
        <Link to="/criancas" className="btn btn-contorno">Cancelar</Link>
      </div>
    </form>
  );
}
