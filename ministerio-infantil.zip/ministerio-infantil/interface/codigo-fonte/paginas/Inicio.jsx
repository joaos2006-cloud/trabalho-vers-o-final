import { Link } from 'react-router-dom';
import { useAuth } from '../contexto/ContextoAutenticacao.jsx';

export default function Home() {
  const { usuario } = useAuth();
  return (
    <section className="hero">
      <div className="hero-texto">
        <h1>Cada criança que chega, registrada em segundos.</h1>
        <p>
          O Check-in Kids ajuda a equipe do ministério infantil a cadastrar as crianças da turma, registrar
          a entrada e a saída em cada culto e ter à mão o contato do responsável e as observações
          importantes, como alergias.
        </p>
        <div className="acoes">
          {usuario ? (
            <Link to="/criancas" className="btn btn-sol">Abrir minha turma</Link>
          ) : (
            <>
              <Link to="/registro" className="btn btn-sol">Criar conta</Link>
              <Link to="/login" className="btn btn-contorno">Já tenho conta</Link>
            </>
          )}
        </div>
      </div>
      <img src="/hero.svg" alt="Crianças brincando diante de uma igreja" className="hero-img" />
    </section>
  );
}
