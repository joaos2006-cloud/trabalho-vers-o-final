import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../servicos/api.js';
import Mensagem from '../componentes/Mensagem.jsx';
import { mensagemDeErro } from '../constantes.js';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ nome: '', email: '', senha: '' });
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  const alterar = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function enviar(e) {
    e.preventDefault();
    setErro('');
    if (form.nome.trim().length < 2) return setErro('Informe seu nome.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) return setErro('Informe um e-mail válido.');
    if (form.senha.length < 6) return setErro('A senha deve ter no mínimo 6 caracteres.');

    setEnviando(true);
    try {
      await api.post('/auth/register', form);
      navigate('/login', { state: { aviso: 'Conta criada! Entre com seu e-mail e senha.' } });
    } catch (err) {
      setErro(mensagemDeErro(err)); //  409 e-mail já cadastrado; os campos continuam preenchidos
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form className="cartao form-estreito" onSubmit={enviar} noValidate>
      <h1>Criar conta</h1>
      <Mensagem>{erro}</Mensagem>
      <label>Nome
        <input name="nome" value={form.nome} onChange={alterar} autoComplete="name" />
      </label>
      <label>E-mail
        <input type="email" name="email" value={form.email} onChange={alterar} autoComplete="email" />
      </label>
      <label>Senha (mínimo 6 caracteres)
        <input type="password" name="senha" value={form.senha} onChange={alterar} autoComplete="new-password" />
      </label>
      <button className="btn btn-sol" disabled={enviando}>{enviando ? 'Criando…' : 'Criar conta'}</button>
      <p className="rodape-form">Já tem conta? <Link to="/login">Entrar</Link></p>
    </form>
  );
}
