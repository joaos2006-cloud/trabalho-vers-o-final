import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import api from '../servicos/api.js';
import Mensagem from '../componentes/Mensagem.jsx';
import { formatarData, formatarDataHora, mensagemDeErro } from '../constantes.js';

export default function CriancaDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [crianca, setCrianca] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  useEffect(() => {
    api
      .get(`/criancas/${id}`)
      .then((r) => setCrianca(r.data))
      .catch((err) => setErro(mensagemDeErro(err))) // 404 se não existir ou for de outro usuário
      .finally(() => setCarregando(false));
  }, [id]);

  async function alternarPresenca() {
    setErro('');
    setSucesso('');
    try {
      const acao = crianca.status === 'presente' ? 'checkout' : 'checkin';
      const r = await api.post(`/criancas/${id}/${acao}`);
      setCrianca(r.data);
      setSucesso(acao === 'checkin' ? 'Check-in registrado.' : 'Saída registrada.');
    } catch (err) {
      setErro(mensagemDeErro(err));
    }
  }

  async function excluir() {
    if (!window.confirm(`Excluir ${crianca.nome}? Essa ação não pode ser desfeita.`)) return;
    try {
      await api.delete(`/criancas/${id}`);
      navigate('/criancas', { state: { sucesso: `${crianca.nome} foi excluída.` } });
    } catch (err) {
      setErro(mensagemDeErro(err));
    }
  }

  if (carregando) return <p className="estado">Carregando…</p>;
  if (!crianca) {
    return (
      <>
        <Mensagem>{erro}</Mensagem>
        <Link to="/criancas" className="btn btn-contorno">Voltar para a turma</Link>
      </>
    );
  }

  return (
    <div className="cartao form-largo">
      <h1>{crianca.nome}</h1>
      <Mensagem tipo="sucesso">{sucesso}</Mensagem>
      <Mensagem>{erro}</Mensagem>

      <dl className="detalhes">
        <dt>Situação</dt>
        <dd><span className={`status status-${crianca.status}`}>{crianca.status === 'presente' ? 'Presente' : 'Ausente'}</span></dd>
        <dt>Turma</dt><dd>{crianca.turma}</dd>
        <dt>Nascimento</dt><dd>{formatarData(crianca.data_nascimento)}</dd>
        <dt>Responsável</dt><dd>{crianca.responsavel}</dd>
        <dt>Telefone</dt><dd>{crianca.telefone_responsavel || '—'}</dd>
        <dt>Observações</dt><dd>{crianca.observacoes || '—'}</dd>
        <dt>Último check-in</dt><dd>{formatarDataHora(crianca.ultimo_checkin)}</dd>
      </dl>

      <div className="acoes">
        <button className={`btn ${crianca.status === 'presente' ? 'btn-contorno' : 'btn-verde'}`} onClick={alternarPresenca}>
          {crianca.status === 'presente' ? 'Registrar saída' : 'Fazer check-in'}
        </button>
        <Link to={`/criancas/${id}/editar`} className="btn btn-contorno">Editar</Link>
        <button className="btn btn-perigo" onClick={excluir}>Excluir</button>
        <Link to="/criancas" className="btn btn-link">Voltar</Link>
      </div>
    </div>
  );
}
