import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexto/ContextoAutenticacao.jsx';
import Mensagem from '../componentes/Mensagem.jsx';
import { mensagemDeErro } from '../constantes.js';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const local = useLocation();
  const [form, setForm] = useState({ email: '', senha: '' });
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  const alterar = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function enviar(e) {
    e.preventDefault();
    setErro('');
    if (!form.email.trim() || !form.senha) return setErro('Preencha e-mail e senha.');
    setEnviando(true);
    try {
      await login(form.email, form.senha);
      navigate(local.state?.de || '/criancas', { replace: true });
    } catch (err) {
      setErro(mensagemDeErro(err)); // e-mail digitado é mantido no formulário
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form className="cartao form-estreito" onSubmit={enviar} noValidate>
      <h1>Entrar</h1>
      <Mensagem tipo="aviso">{local.state?.aviso}</Mensagem>
      <Mensagem>{erro}</Mensagem>
      <label>E-mail
        <input type="email" name="email" value={form.email} onChange={alterar} autoComplete="email" />
      </label>
      <label>Senha
        <input type="password" name="senha" value={form.senha} onChange={alterar} autoComplete="current-password" />
      </label>
      <button className="btn btn-sol" disabled={enviando}>{enviando ? 'Entrando…' : 'Entrar'}</button>
      <p className="rodape-form">Ainda não tem conta? <Link to="/registro">Criar conta</Link></p>
    </form>
  );
}
