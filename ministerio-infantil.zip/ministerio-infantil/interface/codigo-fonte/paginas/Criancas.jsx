import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import api from '../servicos/api.js';
import Mensagem from '../componentes/Mensagem.jsx';
import { TURMAS, formatarDataHora, mensagemDeErro } from '../constantes.js';

export default function Criancas() {
  const local = useLocation();
  const [criancas, setCriancas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState(local.state?.sucesso || '');
  const [filtroTurma, setFiltroTurma] = useState('');

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      const r = await api.get('/criancas');
      setCriancas(r.data);
    } catch (err) {
      setErro(mensagemDeErro(err));
    } finally {
      setCarregando(false);
    }
  }

  useEffect(() => {
    carregar();
  }, []);

  async function alternarPresenca(c) {
    setErro('');
    setSucesso('');
    try {
      const acao = c.status === 'presente' ? 'checkout' : 'checkin';
      const r = await api.post(`/criancas/${c.id}/${acao}`);
      setCriancas(criancas.map((x) => (x.id === c.id ? r.data : x)));
      setSucesso(acao === 'checkin' ? `Check-in de ${c.nome} registrado.` : `Saída de ${c.nome} registrada.`);
    } catch (err) {
      setErro(mensagemDeErro(err));
    }
  }

  async function excluir(c) {
    if (!window.confirm(`Excluir ${c.nome}? Essa ação não pode ser desfeita.`)) return;
    setErro('');
    setSucesso('');
    try {
      await api.delete(`/criancas/${c.id}`);
      setCriancas(criancas.filter((x) => x.id !== c.id));
      setSucesso(`${c.nome} foi excluída.`);
    } catch (err) {
      setErro(mensagemDeErro(err));
    }
  }

  const visiveis = filtroTurma ? criancas.filter((c) => c.turma === filtroTurma) : criancas;
  const presentes = criancas.filter((c) => c.status === 'presente').length;

  return (
    <>
      <div className="topo-pagina">
        <div>
          <h1>Minha turma</h1>
          {!carregando && !erro && (
            <p className="subtitulo">{presentes} presente(s) de {criancas.length} cadastrada(s)</p>
          )}
        </div>
        <Link to="/criancas/nova" className="btn btn-sol">Cadastrar criança</Link>
      </div>

      <Mensagem tipo="sucesso">{sucesso}</Mensagem>
      <Mensagem>{erro}</Mensagem>
      {erro && <button className="btn btn-contorno" onClick={carregar}>Tentar de novo</button>}

      {carregando && <p className="estado">Carregando crianças…</p>}

      {!carregando && !erro && criancas.length === 0 && (
        <div className="cartao vazio">
          <p>Nenhuma criança cadastrada ainda.</p>
          <Link to="/criancas/nova" className="btn btn-sol">Cadastrar a primeira criança</Link>
        </div>
      )}

      {!carregando && criancas.length > 0 && (
        <>
          <label className="filtro">Filtrar por turma
            <select value={filtroTurma} onChange={(e) => setFiltroTurma(e.target.value)}>
              <option value="">Todas</option>
              {TURMAS.map((t) => <option key={t}>{t}</option>)}
            </select>
          </label>

          {visiveis.length === 0 && <p className="estado">Nenhuma criança nessa turma.</p>}

          <ul className="lista">
            {visiveis.map((c) => (
              <li key={c.id} className={`item ${c.status}`}>
                <div className="item-info">
                  <Link to={`/criancas/${c.id}`} className="item-nome">{c.nome}</Link>
                  <span className="etiqueta">{c.turma}</span>
                  <span className={`status status-${c.status}`}>
                    {c.status === 'presente' ? 'Presente' : 'Ausente'}
                  </span>
                  <small>Último check-in: {formatarDataHora(c.ultimo_checkin)}</small>
                </div>
                <div className="item-acoes">
                  <button
                    className={`btn ${c.status === 'presente' ? 'btn-contorno' : 'btn-verde'}`}
                    onClick={() => alternarPresenca(c)}
                  >
                    {c.status === 'presente' ? 'Registrar saída' : 'Fazer check-in'}
                  </button>
                  <Link to={`/criancas/${c.id}/editar`} className="btn btn-contorno">Editar</Link>
                  <button className="btn btn-perigo" onClick={() => excluir(c)}>Excluir</button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </>
  );
}
